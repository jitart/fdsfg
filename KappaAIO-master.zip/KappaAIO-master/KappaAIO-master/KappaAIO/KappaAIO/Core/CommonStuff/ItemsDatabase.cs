﻿using EloBuddy;
using EloBuddy.SDK;

namespace KappaAIO.Core.CommonStuff
{
    public static class ItemsDatabase
    {
        internal static class Items
        {
            // Wards
            public static Item EyeOfTheEquinox = new Item(ItemId.Eye_of_the_Equinox, 600);
            public static Item EyeOfTheOasis = new Item(ItemId.Eye_of_the_Oasis, 600);
            public static Item EyeOfTheWatchers = new Item(ItemId.Eye_of_the_Watchers, 600);
            public static Item TrackerKnife = new Item(ItemId.Trackers_Knife, 600);
            public static Item TrackerKnife_Devourer = new Item(ItemId.Trackers_Knife_Enchantment_Devourer, 600);
            public static Item TrackerKnife_Sated_Devourer = new Item(ItemId.Trackers_Knife_Enchantment_Sated_Devourer, 600);
            public static Item TrackerKnife_Cinderhulk = new Item(ItemId.Trackers_Knife_Enchantment_Cinderhulk, 600);
            public static Item TrackerKnife_Runic_Echoes = new Item(ItemId.Trackers_Knife_Enchantment_Runic_Echoes, 600);
            public static Item TrackerKnife_Warrior = new Item(ItemId.Trackers_Knife_Enchantment_Warrior, 600);
            public static Item SightStone = new Item(ItemId.Sightstone, 600);
            public static Item RubySightStone = new Item(ItemId.Ruby_Sightstone, 600);
            public static Item VisionWard = new Item(ItemId.Vision_Ward, 600);
            public static Item YellowTrinket = new Item(ItemId.Warding_Totem_Trinket, 600);
            public static Item BlueTrinket = new Item(ItemId.Farsight_Alteration, 600);
            public static Item RedTrinket = new Item(ItemId.Sweeping_Lens_Trinket, 600);
            public static Item RedTrinket2 = new Item(ItemId.Oracle_Alteration, 600);

            // Qss
            public static Item Mercurial_Scimitar = new Item(ItemId.Mercurial_Scimitar);
            public static Item Quicksilver_Sash = new Item(ItemId.Quicksilver_Sash);
            public static Item Dervish_Blade = new Item(ItemId.Dervish_Blade);
            public static Item Mikaels = new Item(ItemId.Mikaels_Crucible, 600);

            // AD
            public static Item Youmuus = new Item(ItemId.Youmuus_Ghostblade);
            public static Item Cutlass = new Item(ItemId.Bilgewater_Cutlass, 550);
            public static Item Botrk = new Item(ItemId.Blade_of_the_Ruined_King, 550);
            public static Item Tiamat = new Item(ItemId.Tiamat_Melee_Only, 200);
            public static Item Hydra = new Item(ItemId.Ravenous_Hydra_Melee_Only, 200);
            public static Item TitanicHydra = new Item(3748, 200);

            // AP
            public static Item Hextech_Gunblade = new Item(ItemId.Hextech_Gunblade, 600);
            public static Item Hextech_ProtoBelt = new Item(ItemId.Will_of_the_Ancients, 600);
            public static Item Hextech_GLP = new Item(3030, 600);

            // Pots
            public static Item HealthPotion = new Item(ItemId.Health_Potion);
            public static Item Biscuit = new Item(ItemId.Total_Biscuit_of_Rejuvenation);
            public static Item RefillablePotion = new Item(ItemId.Refillable_Potion);
            public static Item CorruptingPotion = new Item(ItemId.Refillable_Potion);
            public static Item HuntersPotion = new Item(ItemId.Hunters_Potion);

            // Tank
            public static Item Seraphs = new Item(ItemId.Seraphs_Embrace);
            public static Item Zhonyas = new Item(ItemId.Zhonyas_Hourglass);
            public static Item Solari = new Item(ItemId.Locket_of_the_Iron_Solari, 600);
            public static Item Randuins = new Item(ItemId.Randuins_Omen, 450);
        }
    }
}
