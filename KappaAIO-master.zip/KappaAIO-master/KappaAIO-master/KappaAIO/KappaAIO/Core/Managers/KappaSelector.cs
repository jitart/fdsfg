﻿using EloBuddy;

namespace KappaAIO.Core.Managers
{
    internal class KappaSelector
    {
        public static Obj_AI_Base GetTarget(float range, DamageType damageType)
        {
            return null;
        }
    }
}
